package first_assignment;

public class DisplayPattern {
    public static void main(String[] args) {
        System.out.println("\tJ\tA\tV\t  V\t  A");
        System.out.println("\tJ  A A\t V   V   A A");
        System.out.println("J\tJ AAAAA\t  V V   AAAAA");
        System.out.println(" J J A     A   V   A     A");
    }
}

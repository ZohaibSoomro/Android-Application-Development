package first_assignment;

public class CircleAreaAndPerimeter1 {
    public static void main(String[] args) {
        double radius = 5.5;
        double pi = Math.PI;
        double perimeter = 2 * pi * radius;
        double area = pi * radius * radius;
        System.out.println("radius: " + radius);
        System.out.println("Perimeter: " + perimeter);
        System.out.println("Area: " + area);
    }
}

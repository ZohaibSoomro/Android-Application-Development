package first_assignment;

public class RectangleAreaAndPerimeter1 {
    public static void main(String[] args) {
        double pi = Math.PI;
        double width = 4.5, height = 7.9;

        double perimeter = 2 * (width + height);
        double area = width * height;
        System.out.println("width: " + width);
        System.out.println("height: " + height);
        System.out.println("Perimeter: " + perimeter);
        System.out.println("Area: " + area);
    }
}
